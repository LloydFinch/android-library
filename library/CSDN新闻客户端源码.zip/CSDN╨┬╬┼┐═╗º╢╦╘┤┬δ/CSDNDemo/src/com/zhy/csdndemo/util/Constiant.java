package com.zhy.csdndemo.util;

public interface Constiant
{

	String PRE_CSDN_APP = "csdn_app";

}
