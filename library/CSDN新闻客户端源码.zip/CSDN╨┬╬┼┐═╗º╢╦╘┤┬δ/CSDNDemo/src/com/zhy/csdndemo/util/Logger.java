package com.zhy.csdndemo.util;

import android.util.Log;

public class Logger
{
	public static void e(String msg)
	{
		Log.e("xxx", msg);
	}
}
