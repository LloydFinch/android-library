package org.cocos2d.types;

//! 4 ccVertex3FTex2FColor4B
public class ccV3F_C4B_T2F_Quad {
    //! top left
    ccV3F_C4B_T2F	tl;
    //! bottom left
    ccV3F_C4B_T2F	bl;
    //! top right
    ccV3F_C4B_T2F	tr;
    //! bottom right
    ccV3F_C4B_T2F	br;
}

