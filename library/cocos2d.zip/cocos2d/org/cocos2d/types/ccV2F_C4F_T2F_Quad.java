package org.cocos2d.types;

//! 4 ccVertex2FTex2FColor4F Quad
class ccV2F_C4F_T2F_Quad {
    //! bottom left
    ccV2F_C4F_T2F	bl;
    //! bottom right
    ccV2F_C4F_T2F	br;
    //! top left
    ccV2F_C4F_T2F	tl;
    //! top right
    ccV2F_C4F_T2F	tr;
}

