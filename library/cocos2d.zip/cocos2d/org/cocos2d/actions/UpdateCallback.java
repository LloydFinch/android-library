package org.cocos2d.actions;

public interface UpdateCallback {
	void update(float d); 
}
