package com.cs.pageindicator;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
	private ViewPager pager ;
	private TabPageIndicator indicator ;
	TextView textView ;
	private String [] text = new String[]{"电视","综艺","游戏"};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		pager = (ViewPager) findViewById(R.id.vpager);
		indicator = (TabPageIndicator) findViewById(R.id.indicator);
		pager.setAdapter(new PagerAdapter() {
		
			
			@Override
			public boolean isViewFromObject(View arg0, Object arg1) {
				return arg0 == arg1 ;
			}
			
			@Override
			public int getCount() {
				return text.length;
			}

			@Override
			public void destroyItem(ViewGroup container, int position,
					Object object) {
				container.removeView((TextView)object);
			}

			@Override
			public Object instantiateItem(ViewGroup container, int position) {
				textView  = new TextView(getApplicationContext());
				textView.setText(text[position]);
				LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
				container.addView(textView,params );
				return textView;
			}
			
			@Override
			public CharSequence getPageTitle(int position) {
				return  text[position];
			}
		});
		
		indicator.setViewPager(pager);
	}

}
