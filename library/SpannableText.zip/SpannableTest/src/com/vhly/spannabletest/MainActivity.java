package com.vhly.spannabletest;

import java.util.HashMap;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.support.v7.app.ActionBarActivity;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.Log;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity implements TextWatcher {

	private Bitmap bitmap;
	private EditText txtContent;
	private HashMap<String, Bitmap> faces;

	private TextView txtShow;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        txtContent = (EditText)findViewById(R.id.txtContent);
        
        txtContent.setText("Hello World");
        
        SpannableString string = new SpannableString(":)");
        
        // TODO 针对 SpannbleString 进行特定样式的设置和图片的添加或覆盖的操作
        // 根据 SpannableString 字符串的位置信息，进行一些特定操作(Span的设置)
        
        Resources resources = getResources();
        
        // Drawable d = resources.getDrawable(R.drawable.ic_launcher);
        // 使用ImageSpan的时候，一定要使用 Bitmap 作为构造方法的参数，
        // !!! 使用Drawable的情况现在的现象是不显示图片，而直接把指定的位置中的字符串替换成“”
        // ImageSpan imageSpan = new ImageSpan(d);
        
        bitmap = BitmapFactory.decodeResource(resources, R.drawable.face1);
        
        ImageSpan imageSpan = new ImageSpan(this, bitmap);
        
         /*
          * @param what  Span 的实例，用于进行字符串操作的
          * @param start   SpannableString 包含的字符串中需要处理的起始位置
          * @param end     需要处理的字符串的结束位置，这个位置依赖于 flags 参数
          * @param flags 标记 start, end 两个参数的取值方式
          * SpannableString.SPAN_INCLUSIVE_EXCLUSIVE   包含 start，但不包含 end
          * SpannableString.SPAN_INCLUSIVE_INCLUSIVE   包含 start 或者 包含 end 只选其一
          * SpannableString.SPAN_EXCLUSIVE_INCLUSIVE   不包含 start，包含 end
          * SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE   不包含 start，不包含 end，只取其中的部分
          */
        string.setSpan( imageSpan, 0, 2, SpannableString.SPAN_INCLUSIVE_EXCLUSIVE);
        
        // 建议 每一个 SpannableString 里面的字符串内容，如果替换成图像的话，请直接设置完整长度来替换
        // 这样避免输入的时候，ImageSpan 干扰输入的文字。
        
        txtContent.append(string);
        
        txtContent.addTextChangedListener(this);
        
        faces = new HashMap<String, Bitmap>();
        
        Bitmap face1 = BitmapFactory.decodeResource(resources, R.drawable.face1);
        faces.put(":)", face1);
        
        Bitmap face2 = BitmapFactory.decodeResource(resources, R.drawable.face2);
        faces.put(":|", face2);

        Bitmap face3 = BitmapFactory.decodeResource(resources, R.drawable.face3);
        faces.put(":D", face3);
        
        Bitmap face4 = BitmapFactory.decodeResource(resources, R.drawable.face4);
        faces.put(":!", face4);
        
        txtShow = (TextView)findViewById(R.id.txtShow);
        
    }
	
	public void btnSendOnClick(View v){
		String string = txtContent.getText().toString();
		
		/*
		 * 1. 这个注释
		 * 2. 这个注释
		 * 3. 这个注释
		 * 4. 这个注释
		 * 5. 这个注释
		 */
		
		// \d\.\s    ""
//		String ss = "1. xxxx";
//		ss.replaceAll("\\d\\.\\s", "");
		
		//   :)    :[!D\|\)]
		
		// 查找规则  W[opq]d   ->  Wod  Wpd  Wqd
		Pattern pattern = Pattern.compile(":[!D\\|\\)]");
		
		// 匹配器，根据Pattern的规则，查找指定字符串中的内容
		Matcher matcher = pattern.matcher(string);
		
		SpannableString sp = new SpannableString(string);
		
		// Matcher.find() 方法，会默认向下查找匹配的内容
		while (matcher.find()) {
			int start = matcher.start();
			int end = matcher.end();
			
			String group = matcher.group();
			
			Log.d("SpannableTest", "RegEx: start: " + start + " end: " + end
				 + " group:" + group);
			
			if(faces.containsKey(group)){
				Bitmap bmp = faces.get(group);
				ImageSpan imageSpan = new ImageSpan(this, bmp);
				sp.setSpan(imageSpan, start, end, SpannableString.SPAN_INCLUSIVE_EXCLUSIVE);
			}
		}
		txtShow.setText(sp);
	}


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		// TODO 判断当前的内容是什么，是否需要进行图片的替换
		
	}


	@Override
	public void afterTextChanged(Editable s) {
		String string = s.toString();
		
		if(string.length() >= 2){
			String sub = string.substring(string.length() - 2, string.length());
			if(faces.containsKey(sub)){
				Bitmap bitmap1 = faces.get(sub);
				ImageSpan imageSpan = new ImageSpan(this, bitmap1);
				s.setSpan(imageSpan, string.length() - 2, string.length(), SpannableString.SPAN_INCLUSIVE_EXCLUSIVE);
			}
		}
		
		Log.d("SpannableTest", "Text content: " + string);
		
		
//		if(string.endsWith(":)")){  // :D  :| :!
//			// TODO 测试是否在循环调用该方法
//			Log.d("SpannableTest", "afterTextChanged");
//			
//			bitmap = xxxx;
//			}else if(string.endsWith(":D")){
//			bitmap = xxxx;
//			ImageSpan imageSpan = new ImageSpan(this, bitmap);
//			
//			s.setSpan(imageSpan, string.length() - 2, string.length(), SpannableString.SPAN_INCLUSIVE_EXCLUSIVE);
//		
//		}else if(string.endsWith(":!")){
//			bitmap = xxxx;
//			ImageSpan imageSpan = new ImageSpan(this, bitmap);
//			
//			s.setSpan(imageSpan, string.length() - 2, string.length(), SpannableString.SPAN_INCLUSIVE_EXCLUSIVE);
//		
//		}else if(string.endsWith(":|")){
//			bitmap = xxxx;
//			ImageSpan imageSpan = new ImageSpan(this, bitmap);
//			
//			s.setSpan(imageSpan, string.length() - 2, string.length(), SpannableString.SPAN_INCLUSIVE_EXCLUSIVE);
//		
//		}
	}
}
